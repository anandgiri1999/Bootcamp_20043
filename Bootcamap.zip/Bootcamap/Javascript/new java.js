function demoExternalAlert(){
    alert("Internal Alert.");
}
function confirmExternal(){
  if(confirm("Are You sure ....?")){
      alert("YESSS");
  }
  else{
    alert("NOOO ");
  }
}
function promptEXternal(){
  var fName=prompt("Enter Your First Name Here ....");
  var lName=prompt("Enter Your last Name Here.....");
  alert(fName+" "+lName);
}
